<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome-new');
});

Route::get('about', function () {
        return view('info.about');
})->name('about');

Route::get('test', function () {
        return redirect('/profile')->with('new', 'true');
});

Auth::routes();

Route::get('home', 'HomeController@index')->name('home');
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout')->name('logout');

Route::get('profile', 'HomeController@indexProfile')->name('profile');
Route::post('profile', 'HomeController@saveProfile');

Route::get('research', 'ResearchController@index')->name('research');
Route::get('research/new', 'ResearchController@new')->name('research.new');
Route::post('research/new', 'ResearchController@saveNew');
Route::get('research/view/{id}', 'ResearchController@view')->name('research.view');

Route::get('koneksi/admin', 'AdminKoneksiController@admin')->name('koneksi.admin');
Route::get('koneksi/admin/{id}', 'AdminKoneksiController@viewKoneksi')->name('koneksi.view');
Route::post('koneksi/admin/download', 'AdminKoneksiController@download')->name('koneksi.download');
Route::post('koneksi/admin/accept', 'AdminKoneksiController@acceptKoneksi')->name('koneksi.accept');
Route::post('koneksi/admin/delete', 'AdminKoneksiController@deleteKoneksi')->name('koneksi.delete');

Route::get('koneksi/status', 'KoneksiController@status');
Route::get('koneksi/permintaan', 'KoneksiController@index')->name('koneksi');
Route::post('koneksi/permintaan', 'KoneksiController@submit');

<?php $__env->startSection('title'); ?>
  idREN Koneksi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-7 mb-3">
        <h1 class="text-danger mb-5" style="font-size: 5em">Permintaan Koneksi idREN</h1>
        <h2>Data User Peminta</h2>
        <div class="form-group">
          <label class="form-label">Instansi</label>
          <label class="form-control"><?php echo e($user->instansi); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama</label>
          <label class="form-control"><?php echo e($user->name); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Username</label>
          <label class="form-control"><?php echo e($user->username); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <label class="form-control"><?php echo e($user->phone_number); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Peran</label>
          <label class="form-control"><?php echo e($user->peran); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <label class="form-control"><?php echo e($user->email); ?></label>
        </div>

        <h2>Data Koneksi</h2>
        <div class="form-group">
          <label class="form-label">Nama Unit Pengelola IT / Jaringan</label>
          <label class="form-control"><?php echo e($koneksi->nama_unit_pengelola_jaringan); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama Kepala Unit</label>
          <label class="form-control"><?php echo e($koneksi->nama_kepala_unit); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <label class="form-control"><?php echo e($koneksi->email); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nomer HP</label>
          <label class="form-control"><?php echo e($koneksi->nomer_hp); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama Penanggung Jawab Jaringan</label>
          <label class="form-control"><?php echo e($koneksi->nama_penanggung_jawab_jaringan); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nomor ASN atas nama institusi (optional)</label>
          <label class="form-control"><?php echo e($koneksi->nomor_asn); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Blok alamat IP atas nama institusi (optional)</label>
          <label class="form-control"><?php echo e($koneksi->alamat_ip); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama Penyedia Jasa Internet (1)</label>
          <label class="form-control"><?php echo e($koneksi->nama_penyedia_jasa_internet); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama PIC/account manager</label>
          <label class="form-control"><?php echo e($koneksi->nama_pic); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nomor HP PIC/account manager</label>
          <label class="form-control"><?php echo e($koneksi->nomor_hp_pic); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Besar bandwidth internet yang dilanggan</label>
          <label class="form-control"><?php echo e($koneksi->bandwidth_internet); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama Penyedia Jasa Internet (2, jika ada)</label>
          <label class="form-control"><?php echo e($koneksi->nama_penyedia_jasa_internet_2); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nama PIC/account manager</label>
          <label class="form-control"><?php echo e($koneksi->nama_pic_2); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Nomor HP PIC/account manager</label>
          <label class="form-control"><?php echo e($koneksi->nomor_hp_pic_2); ?></label>
        </div>
        <div class="form-group">
          <label class="form-label">Besar bandwidth internet yang dilanggan</label>
          <label class="form-control"><?php echo e($koneksi->bandwidth_internet_2); ?></label>
        </div>
        <div class="form-group">
          <form method="POST" action="<?php echo e(route('koneksi.download')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="filename" value="<?php echo e($user->instansi.' - '.$user->name); ?>" hidden>
            <input type="text" name="file" value="<?php echo e($koneksi->file_path); ?>" hidden>
            <button type="submit" class="custom-file-label::after">Download File</button>
          </form>
        </div>
        <div class="form-inline">
          <form method="POST" action="<?php echo e(route('koneksi.accept')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="id" value="<?php echo e($koneksi->id); ?>" hidden>
            <button type="submit" class="btn btn-primary">Verify Koneksi</button>
          </form>
          <form method="POST" action="<?php echo e(route('koneksi.delete')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" name="id" value="<?php echo e($koneksi->id); ?>" hidden>
            <button type="submit" class="btn btn-danger">Delete</button>
          </form>
        </div>

      </div>
      <div class="col-md-5" style="background-color:#F9D9EB">
        <h1 class="text mb-5" style="font-size: 3em">Flowchart Pengajuan Koneksi</h1>
        <img src="<?php echo e(asset('assets/img/flowchart-con-req.png')); ?>" class="img-fluid" alt="">
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idren\resources\views/koneksi/view.blade.php ENDPATH**/ ?>
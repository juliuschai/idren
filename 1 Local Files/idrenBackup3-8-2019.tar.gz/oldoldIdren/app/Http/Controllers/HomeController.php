<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\University;
use App\User;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home-new');
    }

    public function research()
    {
        return view('research.home');
    }

    public function indexProfile() 
    {
        $user = auth()->user();
        $universities = University::orderBy('instansi')->get(['id','instansi']);
        if (auth()->user()->instansi_id != null) {
            $user->instansiName = University::find(auth()->user()->instansi_id)->instansi;
        }
        return view('profile', compact('user', 'universities'));
    }

    public function saveProfile(Request $request) 
    {
        $this->validate($request, [
            'name' => ['required', 'string', 'max:191'],
            'phone_number' => ['required', 'string', 'max:20'],
            'instansi_id' => ['required', 'string', 'max:191'],
        ]);
        $instansi_id = University::where('instansi', '=', $request['instansi_id'])->first()->id;
        $user = auth()->user();
        $user->name = $request['name'];
        $user->phone_number = $request['phone_number'];
        $user->instansi_id = $instansi_id;
        $user->save();

        $universities = University::orderBy('instansi')->get(['id','instansi']);
        $success = "Berhasil mengupdate profil";
        return redirect()->back()->with(compact('user', 'universities', 'success'));
    }


}
